
module javaproject {
	 requires java.sql;
	 requires java.desktop;
}