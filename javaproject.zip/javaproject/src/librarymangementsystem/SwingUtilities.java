package librarymangementsystem;

public class SwingUtilities {

	public static void invokeLater1(Object object) {
		// TODO Auto-generated method stub
		
	}

	public static void invokeLater(Object object) {
		// TODO Auto-generated method stub
		
	}

}
